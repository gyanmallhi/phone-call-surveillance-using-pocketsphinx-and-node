var PocketSphinx = require('./build/Release/PocketSphinx.node');
var SphinxBase = require('./build/Release/SphinxBase.node');

module.exports = {
    "ps" : PocketSphinx,
    "sb" : SphinxBase
}
