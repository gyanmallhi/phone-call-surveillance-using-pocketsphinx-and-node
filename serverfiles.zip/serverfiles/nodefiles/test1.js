var ffmpeg = require('fluent-ffmpeg');

function convert(name) {
  // body...
  var track = '../uploads/'+name;//your path to source file

  ffmpeg(track)
  .inputFormat('3gp')
  .toFormat('wav')
  .outputOptions([
  '-acodec pcm_s16le',
  '-ac 1',
  '-ar 16000'
  ])
  .on('error', function (err) {
      console.log('An error occurred: ' + err.message);
  })
  .on('progress', function (progress) {
      // console.log(JSON.stringify(progress));
      console.log('Processing: ' + progress.targetSize + ' KB converted');
  })
  .on('end', function () {
      console.log('Processing finished !');
  })
  .save('../uploads/audioconv.wav');//path where you want to save your file

}
module.exports = {
  convert
};