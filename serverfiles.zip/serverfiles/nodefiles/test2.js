//This file contains the voice to text conversion and keyword detection
//it generates points and sen
var fs = require('fs');

var ps = require('..').ps;
//add your email username and password here
var mail = require('node-smtp-client').Mail({
  host: 'smtp.gmail.com',
  username: '',
  password: ''
});
 //using the pocketsphinx API
function run(name) {
	modeldir = "../pocketsphinx/model/en-in/";

var config = new ps.Decoder.defaultConfig();
config.setString("-hmm", modeldir + "en-us");
config.setString("-dict", modeldir + "cmudict-en-us.dict");
config.setString("-lm", modeldir + "en-us.lm.bin");
var decoder = new ps.Decoder(config);

var string = "";
var keywords =["bank","oh","tea","pea","password","details","account","sea","we","pin","code","card","expiry","attended","return","corporate","for"];
var points = 0
fs.readFile("../uploads/"+name, function(err, data) {
    if (err) throw err;
    decoder.startUtt();
    decoder.processRaw(data, false, false);
    decoder.endUtt();
    string = decoder.hyp().hypstr;
    console.log(string);
    
	keywords.forEach(function(keyword){
    	if (string.indexOf(keyword) !== -1) {
    		points += 10;
    		}
    	});
	//console.log(String(points));
    fs.writeFile("../text/transcripts.txt", string, function(err) {
    if(err) {
        return console.log(err);
    }
    });
    var newpoints = 0;
    fs.readFile("../text/points.txt", function (err, data) {
        if(err){
        return console.log(err);
        }
        //the points generation system
        newpoints = parseInt(data, 10);
        newpoints = newpoints + points;
        // add the user email here in to: and sender email in from:
        if(newpoints > 100){
                mail.message({
                  from: '',
                  to: [''],
                  subject: 'Hello from Node.JS'
                })
                .body("your bank details may be compromised detected level "+String(newpoints)+' out of 100')
                .send(function(err) {
                  if (err) throw err;
                  console.log('Sent!');
                });
        }
        //add the user email here in to: and sender email in from:
        else if(newpoints < 100){
                mail.message({
                  from: '',
                  to: [''],
                  subject: 'Hello from Node.JS'
                })
                .body("call was safe "+String(newpoints)+' out of 100')
                .send(function(err) {
                  if (err) throw err;
                  console.log('Sent!');
                });
        }
    });
    
    if(newpoints<100){

        fs.writeFile("../text/points.txt", String(newpoints), function(err) {
            if(err) {
                return console.log(err);
                }
            }); 
    

        }
    

    console.log("The file was saved!");
    


    
	});


}


module.exports = {
	run
};